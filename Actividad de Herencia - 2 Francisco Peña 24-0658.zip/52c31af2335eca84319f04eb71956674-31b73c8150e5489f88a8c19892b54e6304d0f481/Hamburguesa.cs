public class Hamburguesa
{
    protected string tipoPan;
    protected string tipoCarne;
    protected double precioBase;
    protected List<(string nombre, double precio)> ingredientesAdicionales;

    public Hamburguesa(string tipoPan, string tipoCarne, double precioBase)
    {
        this.tipoPan = tipoPan;
        this.tipoCarne = tipoCarne;
        this.precioBase = precioBase;
        ingredientesAdicionales = new List<(string, double)>();
    }

    public virtual void AgregarIngrediente(string nombre, double precio)
    {
        if (ingredientesAdicionales.Count < 4)
        {
            ingredientesAdicionales.Add((nombre, precio));
        }
        else
        {
            Console.WriteLine("No se pueden agregar más de 4 ingredientes adicionales.");
        }
    }

    public virtual void MostrarFactura()
    {
        Console.WriteLine($"Hamburguesa con pan: {tipoPan}, carne: {tipoCarne}");
        Console.WriteLine($"Precio base: RD${precioBase:F2}");

        double total = precioBase;

        foreach (var ingrediente in ingredientesAdicionales)
        {
            Console.WriteLine($" + {ingrediente.nombre}: RD${ingrediente.precio:F2}");
            total += ingrediente.precio;
        }

        Console.WriteLine($"Total: RD${total:F2}\n");
    }
}
