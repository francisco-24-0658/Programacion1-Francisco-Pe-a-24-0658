public class HamburguesaSaludable : Hamburguesa
{
    private List<(string nombre, double precio)> ingredientesSaludables;

    public HamburguesaSaludable(string tipoCarne, double precioBase)
        : base("Integral", tipoCarne, precioBase)
    {
        ingredientesSaludables = new List<(string, double)>();
    }

    public void AgregarIngredienteSaludable(string nombre, double precio)
    {
        if (ingredientesAdicionales.Count + ingredientesSaludables.Count < 6)
        {
            ingredientesSaludables.Add((nombre, precio));
        }
        else
        {
            Console.WriteLine("No se pueden agregar más de 6 ingredientes adicionales en total.");
        }
    }

    public override void MostrarFactura()
    {
        base.MostrarFactura();

        double total = precioBase;
        foreach (var ingrediente in ingredientesAdicionales)
        {
            total += ingrediente.precio;
        }

        foreach (var ingrediente in ingredientesSaludables)
        {
            Console.WriteLine($" + {ingrediente.nombre} (saludable): RD${ingrediente.precio:F2}");
            total += ingrediente.precio;
        }

        Console.WriteLine($"Total: RD${total:F2}\n");
    }
}
