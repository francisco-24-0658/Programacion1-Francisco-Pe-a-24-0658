class Program
{
    static void Main()
    {
        var clasica = new Hamburguesa("Pan blanco", "Res", 150);
        clasica.AgregarIngrediente("Lechuga", 10);
        clasica.AgregarIngrediente("Tomate", 8);
        clasica.AgregarIngrediente("Bacon", 25);
        clasica.MostrarFactura();

        var saludable = new HamburguesaSaludable("Pollo", 170);
        saludable.AgregarIngrediente("Tomate", 8);
        saludable.AgregarIngredienteSaludable("Aguacate", 20);
        saludable.AgregarIngredienteSaludable("Brocoli", 15);
        saludable.MostrarFactura();

        var premium = new HamburguesaPremium("Pan brioche", "Angus", 250);
        premium.AgregarIngrediente("Cebolla caramelizada", 15); // No se permitirá
        premium.MostrarFactura();
    }
}
