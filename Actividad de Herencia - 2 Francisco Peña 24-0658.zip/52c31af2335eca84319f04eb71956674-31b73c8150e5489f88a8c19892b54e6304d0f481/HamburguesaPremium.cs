public class HamburguesaPremium : Hamburguesa
{
    public HamburguesaPremium(string tipoPan, string tipoCarne, double precioBase)
        : base(tipoPan, tipoCarne, precioBase)
    {
        // Se agregan automáticamente papitas y bebida
        ingredientesAdicionales.Add(("Papitas", 50.0));
        ingredientesAdicionales.Add(("Bebida", 40.0));
    }

    public override void AgregarIngrediente(string nombre, double precio)
    {
        Console.WriteLine("No se pueden agregar más ingredientes a la hamburguesa premium.");
    }
}
