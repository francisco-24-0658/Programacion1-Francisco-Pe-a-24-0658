namespace CentralitaTelefonica
{
    public class LlamadaProvincial : Llamada
    {
        private const float PrecioFranja1 = 0.15f;
        private const float PrecioFranja2 = 0.15f;
        private const float PrecioFranja3 = 0.15f;

        public int Franja { get; private set; }

        public LlamadaProvincial(string numOrigen, string numDestino, int franja)
            : base(numOrigen, numDestino)
        {
            Franja = franja;
        }

        public override float CalcularPrecio()
        {
            float precio = Franja switch
            {
                1 => PrecioFranja1,
                2 => PrecioFranja2,
                3 => PrecioFranja3,
                _ => PrecioFranja1
            };
            return duracion * precio;
        }

        public override string EstadoActual()
        {
            return $"[PROVINCIAL] {base.EstadoActual()} | Franja: {Franja}";
        }

        public override string ToString()
        {
            return $"[PROVINCIAL] {base.ToString()} | Franja: {Franja}";
        }
    }
}