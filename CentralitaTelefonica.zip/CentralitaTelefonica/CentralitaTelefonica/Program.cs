﻿using System;
using System.Threading;

namespace CentralitaTelefonica
{
    class Program
    {
        static void Main(string[] args)
        {
            Centralita centralita = new Centralita();
            bool salir = false;

            while (!salir)
            {
                Console.Clear();
                Console.WriteLine("=== CENTRALITA TELEFÓNICA ===");
                Console.WriteLine("1. Iniciar llamada local");
                Console.WriteLine("2. Iniciar llamada provincial");
                Console.WriteLine("3. Finalizar llamada actual");
                Console.WriteLine("4. Ver estado actual");
                Console.WriteLine("5. Ver historial");
                Console.WriteLine("6. Ver informe");
                Console.WriteLine("7. Salir");
                Console.Write("\nSeleccione opción: ");

                switch (Console.ReadLine())
                {
                    case "1":
                        Console.Write("\nNúmero origen: ");
                        string origen = Console.ReadLine();
                        Console.Write("Número destino: ");
                        centralita.IniciarLlamada(new LlamadaLocal(origen, Console.ReadLine()));
                        break;

                    case "2":
                        Console.Write("\nNúmero origen: ");
                        origen = Console.ReadLine();
                        Console.Write("Número destino: ");
                        string destino = Console.ReadLine();
                        Console.Write("Franja horaria (1-3): ");
                        if (int.TryParse(Console.ReadLine(), out int franja) && franja >= 1 && franja <= 3)
                        {
                            centralita.IniciarLlamada(new LlamadaProvincial(origen, destino, franja));
                        }
                        else
                        {
                            Console.WriteLine("\nFranja inválida. Usando franja 1.");
                            centralita.IniciarLlamada(new LlamadaProvincial(origen, destino, 1));
                        }
                        break;

                    case "3":
                        double costo = centralita.FinalizarLlamadaActual();
                        Console.WriteLine($"\nCosto: {costo:C}");
                        break;

                    case "4":
                        centralita.MostrarEstadoActual();
                        break;

                    case "5":
                        centralita.MostrarHistorial();
                        break;

                    case "6":
                        centralita.MostrarInforme();
                        break;

                    case "7":
                        salir = true;
                        break;

                    default:
                        Console.WriteLine("\nOpción no válida");
                        break;
                }

                if (!salir)
                {
                    Console.WriteLine("\nPresione cualquier tecla para continuar...");
                    Console.ReadKey();
                }
            }
        }
    }
}