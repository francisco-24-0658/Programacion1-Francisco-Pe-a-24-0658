﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaTelefonica
{
    public class AppDbContext: DbContext
    {
        public DbSet<DbService> Centralita { get; set; }
   

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=tcp:franciscopena.database.windows.net,1433;" +
                                        "Initial Catalog=Francisco240658;" +
                                        "Persist Security Info=False;" +
                                        "User ID=Francisco_server;" +
                                        "Password=Fpena11*;" +
                                        "MultipleActiveResultSets=False;" +
                                        "Encrypt=True;" +
                                        "TrustServerCertificate=False;" +
                                        "Connection Timeout=30;");
        }
    }
}
