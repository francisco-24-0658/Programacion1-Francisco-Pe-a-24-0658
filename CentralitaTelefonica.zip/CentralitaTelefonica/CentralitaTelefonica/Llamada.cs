using System;
using System.Diagnostics;
using System.Threading;

namespace CentralitaTelefonica
{
    public abstract class Llamada
    {
        protected string numOrigen;
        protected string numDestino;
        protected float duracion;
        protected Stopwatch temporizador;
        protected bool enCurso;

        public string NumOrigen => numOrigen;
        public string NumDestino => numDestino;
        public float Duracion => duracion;
        public bool EnCurso => enCurso;

        public Llamada(string numOrigen, string numDestino)
        {
            this.numOrigen = numOrigen;
            this.numDestino = numDestino;
            this.temporizador = new Stopwatch();
        }

        public void IniciarLlamada()
        {
            if (!enCurso)
            {
                temporizador.Start();
                enCurso = true;
                Console.WriteLine($"\nLlamada iniciada: {numOrigen} -> {numDestino}");
            }
        }

        public float FinalizarLlamada()
        {
            if (enCurso)
            {
                temporizador.Stop();
                enCurso = false;
                duracion = (float)temporizador.Elapsed.TotalSeconds;
                Console.WriteLine($"\nLlamada finalizada. Duraci�n: {duracion:F2} segundos");
                return CalcularPrecio();
            }
            return 0;
        }

        public abstract float CalcularPrecio();

        public virtual string EstadoActual()
        {
            return $"Llamada {numOrigen} -> {numDestino} | " +
                   $"Tiempo: {temporizador.Elapsed:mm\\:ss} | " +
                   $"En curso: {(enCurso ? "S�" : "No")}";
        }

        public override string ToString()
        {
            return $"Llamada de {numOrigen} a {numDestino} | " +
                   $"{duracion:F2}s | Coste: {CalcularPrecio():C}";
        }
    }
}