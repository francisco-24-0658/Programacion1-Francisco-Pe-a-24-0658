namespace CentralitaTelefonica
{
    public class LlamadaLocal : Llamada
    {
        private const float PrecioPorSegundo = 0.15f;

        public LlamadaLocal(string numOrigen, string numDestino)
            : base(numOrigen, numDestino)
        {
        }

        public override float CalcularPrecio()
        {
            return duracion * PrecioPorSegundo;
        }

        public override string EstadoActual()
        {
            return $"[LOCAL] {base.EstadoActual()}";
        }

        public override string ToString()
        {
            return $"[LOCAL] {base.ToString()}";
        }
    }
}