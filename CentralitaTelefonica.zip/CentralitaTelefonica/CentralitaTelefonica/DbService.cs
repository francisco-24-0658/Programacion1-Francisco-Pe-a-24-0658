﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaTelefonica
{
    public class DbService
    {
        public int Id { get; set; }

        // Cambio de nombre (antes era NumeroOrigen)
        public string TelefonoOrigen { get; set; }

        public string NumeroDestino { get; set; }
        public float Duracion { get; set; }

        // Nueva propiedad
        public float Costo { get; set; }
        public override string ToString()
        {
            return $"Llamada de {TelefonoOrigen} a {NumeroDestino} | " +
                   $"{Duracion:F2}s | Coste: {Costo:C}";
        }
    }
}
