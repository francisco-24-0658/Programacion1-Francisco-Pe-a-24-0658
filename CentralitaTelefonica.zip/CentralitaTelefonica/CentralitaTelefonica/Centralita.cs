﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CentralitaTelefonica
{
    public class Centralita
    {
        private List<Llamada> llamadas = new List<Llamada>();
        private Llamada llamadaActual;

        public void IniciarLlamada(Llamada llamada)
        {
            if (llamadaActual == null)
            {
                llamadaActual = llamada;
                llamadaActual.IniciarLlamada();
            }
            else
            {
                Console.WriteLine("\nYa hay una llamada en curso!");
            }
        }

        public double FinalizarLlamadaActual()
        {
            if (llamadaActual != null)
            {
                float costo = llamadaActual.FinalizarLlamada();
                AppDbContext dbContext = new AppDbContext();
                var Llamadamanager =new DatabaseManager<DbService>(dbContext);
                DbService dbService = new DbService();

                dbService.TelefonoOrigen = llamadaActual.NumOrigen;
                dbService.NumeroDestino = llamadaActual.NumDestino;
                dbService.Duracion= (float)Math.Round(llamadaActual.Duracion, 2); 
                
                dbService.Costo = (float)Math.Round(costo, 2);

                Llamadamanager.Add(dbService);

                llamadaActual = null;
                return costo;
            }
            Console.WriteLine("\nNo hay llamada en curso para finalizar");
            return 0;
        }

        public void MostrarEstadoActual()
        {
            if (llamadaActual != null)
            {
                Console.WriteLine($"\n{llamadaActual.EstadoActual()}");
            }
            else
            {
                Console.WriteLine("\nNo hay llamadas en curso");
            }
        }

        public void MostrarHistorial()
        {
            Console.WriteLine("\n=== HISTORIAL DE LLAMADAS ===");
            AppDbContext dbContext = new AppDbContext();
            var Llamadamanager = new DatabaseManager<DbService>(dbContext);

           var dbService = new List<DbService>();

            dbService = (List<DbService>)Llamadamanager.GetAll();
            if (dbService.Any())
            {
                foreach (var llamada in dbService)
                {
                    Console.WriteLine(llamada.ToString());
                }
            }
            else
            {
                Console.WriteLine("No hay llamadas registradas");
            }
            Console.WriteLine("============================");
        }

        public void MostrarInforme()
        {
            AppDbContext dbContext = new AppDbContext();
            var Llamadamanager = new DatabaseManager<DbService>(dbContext);

            var dbService = new List<DbService>();

            dbService = (List<DbService>)Llamadamanager.GetAll();

            Console.WriteLine("\n=== INFORME DE CENTRALITA ===");
            Console.WriteLine($"Total llamadas: {dbService.Count}");
            float precio_total = 0.0f;
            foreach (var llamada in dbService)
            {
                precio_total += llamada.Costo;
            }
            Console.WriteLine($"Total facturado: {precio_total}");
            Console.WriteLine("============================");
        }
    }
}